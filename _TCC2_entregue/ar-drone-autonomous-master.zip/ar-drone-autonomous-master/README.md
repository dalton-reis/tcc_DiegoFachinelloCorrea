# ar-drone-autonomous
Project to developer an Ar drone 2.0 autonomous with GPS module 
